<?php
error_reporting(E_ALL & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 1);
include 'db.php';

// Get latest quiz response
$sql = "SELECT * FROM quiz_responses ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);

$matches = []; // Ensure it's defined

if ($result && $result->num_rows > 0) {
  $response = $result->fetch_assoc();
  $name = htmlspecialchars($response['name'] ?? '');

  echo "<h2 style='text-align:center;color:#0ff;'>Hi, $name! Here are your recommended careers:</h2>";

  $matchSQL = "
    SELECT 
      r.*, 
      (
        (r.interest = '{$response['interest']}') +
        (r.skill = '{$response['skill']}') +
        (r.motivation = '{$response['motivation']}') +
        (r.people = '{$response['people']}') +
        (r.approach = '{$response['approach']}') +
        (r.expression = '{$response['expression']}') +
        (r.environment = '{$response['environment']}') +
        (r.stress = '{$response['stress']}') +
        (r.thinking = '{$response['thinking']}') +
        (r.impact = '{$response['impact']}') +
        (r.success = '{$response['success']}') +
        (r.goal = '{$response['goal']}') +
        (r.productivity = '{$response['productivity']}') +
        (r.avoid_job = '{$response['avoid_job']}')
      ) AS match_score
    FROM results r
    ORDER BY match_score DESC, r.career_name ASC
    LIMIT 10
  ";

  $matchedResults = $conn->query($matchSQL);
  $hasMatch = false;

  if ($matchedResults && $matchedResults->num_rows > 0) {
    while ($row = $matchedResults->fetch_assoc()) {
      if (($row['match_score'] ?? 0) >= 5) {
        $hasMatch = true;
        $matches[] = $row;
      }
    }
  }

} else {
  echo "<div class='message'>⚠️ No form submitted.<br>
        <a class='btn-start' href='quiz.php'>Take Quiz</a></div>";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PathPilot Results</title>
  <style>
    body {
      margin: 0;
      background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
      font-family: 'Segoe UI', sans-serif;
      color: #fff;
    }
    h1 {
      text-align: center;
      margin-top: 40px;
      color: #00c6ff;
    }
    .card-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
      padding: 30px;
    }
    .card {
      background: white;
      border-radius: 10px;
      padding: 15px;
      width: 250px;
      color: #000;
      text-align: center;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      cursor: pointer;
      transition: transform 0.2s;
    }
    .card:hover {
      transform: scale(1.05);
    }
    .card img {
      width: 100%;
      height: 150px;
      object-fit: contain;
      border-radius: 5px;
    }
    .details-block {
      background: #e7f1ff;
      margin: 10px auto;
      width: 80%;
      padding: 15px;
      border-radius: 10px;
      box-shadow: 0 0 5px #bbb;
      display: none;
      color: #000;
    }
    .details-block h4 {
      margin-bottom: 5px;
      color: #333;
    }
    .details-block ul {
      list-style-type: square;
      padding-left: 20px;
    }
    .details-block a {
      display: block;
      color: #007bff;
      text-decoration: none;
      margin: 2px 0;
    }
    .match-percent {
      font-weight: bold;
      color: green;
      margin-bottom: 10px;
    }
    .btn-start {
      display: inline-block;
      margin-top: 30px;
      padding: 12px 25px;
      background-color: #00c6ff;
      color: #fff;
      font-weight: 600;
      text-decoration: none;
      border-radius: 6px;
      transition: 0.3s ease;
    }
    .btn-start:hover {
      background-color: #009ecc;
    }
    .no-matches {
      text-align: center;
      font-size: 1.2em;
      padding: 30px;
    }
  </style>
</head>
<body>



<div class="card-container">
  <?php if (count($matches) > 0): ?>
    <?php foreach ($matches as $match): ?>
      <div class="card" onclick="toggleDetails('details-<?= $match['id'] ?>')">
        <img src="<?= htmlspecialchars($match['image_url'] ?? '') ?>" alt="<?= htmlspecialchars($match['career_name'] ?? '') ?>">
        <h3><?= htmlspecialchars($match['career_name'] ?? 'Career') ?></h3>
        <p class="match-percent">Match: <?= $match['match_score'] ?>/14</p>
      </div>

      <div class="details-block" id="details-<?= $match['id'] ?>">
        <h4>🎓 Degree:</h4>
        <p><?= htmlspecialchars($match['degree'] ?? 'Not specified') ?></p>

        <h4>🛠 Skills:</h4>
        <ul>
          <?php
          $skills = isset($match['skills']) ? explode(',', $match['skills']) : [];
          foreach ($skills as $skill): ?>
            <li><?= htmlspecialchars(trim($skill)) ?></li>
          <?php endforeach; ?>
        </ul>

        <h4>📚  Short-Term Courses:</h4>
        <?php
        $courses = isset($match['courses']) ? explode(',', $match['courses']) : [];
        foreach ($courses as $course_link):
          $url = trim($course_link);
          if (!empty($url)):
        ?>
          <a href="<?= htmlspecialchars($url) ?>" target="_blank">🔗 <?= htmlspecialchars($url) ?></a>
        <?php endif; endforeach; ?>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <div class="no-matches">⚠ No career matches found. Please try again with a completed quiz.</div>
    <div style="text-align:center;">
      <a href="quiz.php" class="btn-start">Start Again</a>
    </div>
  <?php endif; ?>
</div>

<script>
  function toggleDetails(id) {
    const block = document.getElementById(id);
    block.style.display = block.style.display === "block" ? "none" : "block";
  }
</script>

</body>
</html>
