
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Detect environment based on hostname
if ($_SERVER['HTTP_HOST'] === 'localhost') {
    // ✅ LOCAL XAMPP SETTINGS
    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "path_pilot"; // You must create this DB in XAMPP
} else {
    // ✅ LIVE INFINITYFREE SETTINGS
    $host = "sql110.infinityfree.com";
    $username = "if0_39407027";
    $password = "De7Th7kHX7";
    $dbname = "if0_39407027_path_pilot";
}

$port = 3306;

// Attempt connection
$conn = new mysqli($host, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("❌ DB Connection failed: " . $conn->connect_error);
}
?>
