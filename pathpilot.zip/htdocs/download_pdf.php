<?php
require 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;
$career = isset($_POST['career']) ? $_POST['career'] : 'Not Available';
$courses = isset($_POST['courses']) ? $_POST['courses'] : 'Not Available';
$dompdf = new Dompdf();
$html = '
<html><body>
<h1>🎯 Career Path: ' . $career . '</h1>
<h2>📚 Courses: ' . $courses . '</h2>
</body></html>';
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("PathPilot_Career_Result.pdf", array("Attachment" => 1));
?>