<?php
include 'db.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Fallback if keys are missing
$name = $_POST['name'] ?? '';
$interest = $_POST['interest'] ?? '';
$motivation = $_POST['motivation'] ?? '';
$skill = $_POST['skill'] ?? '';
$people = $_POST['people'] ?? '';
$success = $_POST['success'] ?? '';
$approach = $_POST['approach'] ?? '';
$thinking = $_POST['thinking'] ?? '';
$expression = $_POST['expression'] ?? '';
$stress = $_POST['stress'] ?? '';
$environment = $_POST['environment'] ?? '';
$impact = $_POST['impact'] ?? '';
$goal = $_POST['goal'] ?? '';
$productivity = $_POST['productivity'] ?? '';
$avoid_job = $_POST['avoid_job'] ?? '';

// Double check name is not empty
if (empty($name)) {
    die("❌ Error: Name is required.");
}

// Insert into database
$sql = "INSERT INTO quiz_responses (
  name, interest, motivation, skill, people, success,
  approach, thinking, expression, stress, environment,
  impact, goal, productivity, avoid_job
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("❌ SQL Prepare Failed: " . $conn->error);
}

$stmt->bind_param(
  "sssssssssssssss",
  $name, $interest, $motivation, $skill, $people, $success,
  $approach, $thinking, $expression, $stress, $environment,
  $impact, $goal, $productivity, $avoid_job
);

if ($stmt->execute()) {
    header("Location: result.php");
    exit();
} else {
    echo "❌ Execute failed: " . $stmt->error;
}

$conn->close();
?>
