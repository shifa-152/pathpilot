<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();
include 'db.php';

$customer_name = $_SESSION['customer_name'] ?? null;
$order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

$order = null;

if ($order_id > 0) {
    // Show only that order
    $stmt = $conn->prepare("SELECT * FROM Orders WHERE order_id = ?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
} elseif ($customer_name) {
    // Show all orders for this customer
    $stmt = $conn->prepare("SELECT * FROM Orders WHERE customer_name = ? ORDER BY order_date DESC");
    $stmt->bind_param("s", $customer_name);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = false;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Track Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        th {
            background-color: #007BFF;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .back-btn {
            display: inline-block;
            margin: 20px auto;
            padding: 10px 20px;
            background: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }

        .footer {
            text-align: center;
            color: #888;
            margin-top: 40px;
        }

        .error-msg {
            text-align: center;
            color: red;
            font-size: 18px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Track Orders</h2>
    <?php if ($customer_name): ?>
        <h3>Orders for <?php echo htmlspecialchars($customer_name); ?></h3>
    <?php endif; ?>

    <?php
    if ($result && $result->num_rows > 0) {
        echo "<table>";
        echo "<tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Total (₹)</th>
                <th>Date</th>
              </tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['order_id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['customer_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
            echo "<td>" . $row['quantity'] . "</td>";
            echo "<td>" . number_format($row['total_price'], 2) . "</td>";
            echo "<td>" . $row['order_date'] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<p class='error-msg'>No orders found.</p>";
    }
    ?>

    <div style="text-align: center;">
        <a href="index.php" class="back-btn">🏠 Back to Home</a>
    </div>
</div>

<div class="footer">
    © 2025 PetStyle Hub. Made with ❤️ by Shifa Pawaskar
</div>

</body>
</html>
