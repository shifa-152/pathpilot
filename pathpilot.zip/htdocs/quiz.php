<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>PathPilot Career Quiz</title>
  <style>
    body {
      margin: 0;
      background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
      font-family: 'Segoe UI', sans-serif;
      color: #fff;
    }
    h1 {
      text-align: center;
      margin-top: 40px;
      color: #00c6ff;
    }
    form {
      background: rgba(255, 255, 255, 0.05);
      max-width: 750px;
      margin: 30px auto;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 0 20px rgba(0, 198, 255, 0.2);
    }
    label {
      display: block;
      margin-top: 25px;
      font-weight: 600;
    }
    select, .radio-group {
      width: 100%;
      margin-top: 5px;
    }
    select {
      padding: 12px;
      border-radius: 8px;
      background-color: rgba(255,255,255,0.1);
      color: #fff;
      border: none;
    }
    select option {
      background: #243b55;
    }
    .radio-group label {
      display: block;
      margin: 8px 0;
    }
    .radio-group input[type="radio"] {
      margin-right: 10px;
      transform: scale(1.1);
    }
    button {
      margin-top: 35px;
      width: 100%;
      padding: 15px;
      background-color: #00c6ff;
      border: none;
      color: #000;
      font-weight: bold;
      border-radius: 10px;
      font-size: 1.1em;
      cursor: pointer;
      transition: 0.3s ease-in-out;
    }
    button:hover {
      background-color: #fff;
      color: #141e30;
    }
  </style>
</head>
<body>

<h1>PathPilot Career Quiz</h1>

<form id="careerQuiz" method="post" action="submit_quiz.php">
  <label>Name</label>
  <input type="text" name="name" placeholder="Enter your name" required style="width:100%;padding:12px;border-radius:8px;border:none;margin-top:5px;background:rgba(255,255,255,0.1);color:#fff;">

  <label>1. What's your primary area of interest?</label>
  <select name="interest" required>
    <option disabled selected value="">Select...</option>
    <option>Technology</option>
    <option>Healthcare</option>
    <option>Arts</option>
    <option>Finance</option>
    <option>Education</option>
    <option>Gaming</option>
    <option>Social Impact</option>
    <option>Forensics</option>
    <option>Space</option>
    <option>Linguistics</option>
    <option>Sports</option>
  </select>

  <label>2. What motivates you most?</label>
  <div class="radio-group">
    <label><input type="radio" name="motivation" value="Impact" required> Impact</label>
    <label><input type="radio" name="motivation" value="Money"> Money</label>
    <label><input type="radio" name="motivation" value="Passion"> Passion</label>
    <label><input type="radio" name="motivation" value="Startup"> Startup</label>
  </div>

  <label>3. What is your core skill?</label>
  <select name="skill" required>
    <option disabled selected value="">Select...</option>
    <option>Problem Solving</option>
    <option>Empathy</option>
    <option>Creativity</option>
    <option>Analytical Thinking</option>
    <option>Communication</option>
    <option>Design Thinking</option>
    <option>Leadership</option>
  </select>

  <label>4. What kind of people do you like working with?</label>
  <select name="people" required>
    <option disabled selected value="">Select...</option>
    <option>Logical Thinkers</option>
    <option>Artists</option>
    <option>Empathetic Individuals</option>
    <option>Leaders</option>
    <option>Collaborators</option>
  </select>

  <label>5. What does success mean to you?</label>
  <div class="radio-group">
    <label><input type="radio" name="success" value="Freedom" required> Freedom</label>
    <label><input type="radio" name="success" value="Recognition"> Recognition</label>
    <label><input type="radio" name="success" value="Security"> Security</label>
  </div>

  <label>6. How do you prefer to approach problems?</label>
  <select name="approach" required>
    <option disabled selected value="">Select...</option>
    <option>Logically</option>
    <option>Creatively</option>
    <option>Emotionally</option>
  </select>

  <label>7. How do you think?</label>
  <div class="radio-group">
    <label><input type="radio" name="thinking" value="Systematic" required> Systematic</label>
    <label><input type="radio" name="thinking" value="Abstract"> Abstract</label>
    <label><input type="radio" name="thinking" value="Observation"> Observation</label>
  </div>

  <label>8. How do you express yourself best?</label>
  <select name="expression" required>
    <option disabled selected value="">Select...</option>
    <option>Code</option>
    <option>Art</option>
    <option>Writing</option>
    <option>Logic</option>
  </select>

  <label>9. How well do you handle stress?</label>
  <div class="radio-group">
    <label><input type="radio" name="stress" value="Very Well" required> Very Well</label>
    <label><input type="radio" name="stress" value="Average"> Average</label>
    <label><input type="radio" name="stress" value="Prefer Calm"> Prefer Calm</label>
  </div>

  <label>10. What environment do you prefer?</label>
  <select name="environment" required>
    <option disabled selected value="">Select...</option>
    <option>Office</option>
    <option>Remote</option>
    <option>Outdoors</option>
  </select>

  <label>11. What kind of impact do you want to create?</label>
  <div class="radio-group">
    <label><input type="radio" name="impact" value="Emotional" required> Emotional</label>
    <label><input type="radio" name="impact" value="Intellectual"> Intellectual</label>
    <label><input type="radio" name="impact" value="Social"> Social</label>
  </div>

  <label>12. What is your ultimate goal?</label>
  <div class="radio-group">
    <label><input type="radio" name="goal" value="Expert" required> Expert</label>
    <label><input type="radio" name="goal" value="Leader"> Leader</label>
    <label><input type="radio" name="goal" value="Startup"> Startup</label>
  </div>

  <label>13. What boosts your productivity?</label>
  <div class="radio-group">
    <label><input type="radio" name="productivity" value="Quiet Space" required> Quiet Space</label>
    <label><input type="radio" name="productivity" value="Teamwork"> Teamwork</label>
    <label><input type="radio" name="productivity" value="Flexible Routine"> Flexible Routine</label>
  </div>

  <label>14. What type of job do you want to avoid?</label>
  <div class="radio-group">
    <label><input type="radio" name="avoid_job" value="Repetitive" required> Repetitive</label>
    <label><input type="radio" name="avoid_job" value="High Pressure"> High Pressure</label>
    <label><input type="radio" name="avoid_job" value="Low Creativity"> Low Creativity</label>
  </div>

  <button type="submit">🚀 Submit Quiz</button>
</form>

<script>
  const form = document.getElementById('careerQuiz');
  const formDataKey = "pathpilot_quiz_data";

  window.onload = function () {
    const saved = JSON.parse(localStorage.getItem(formDataKey) || "{}");
    Object.keys(saved).forEach(name => {
      const field = form.elements[name];
      if (field) {
        if (field.type === "radio" || field.length > 1) {
          const options = form.querySelectorAll(`[name="${name}"]`);
          options.forEach(opt => {
            if (opt.value === saved[name]) opt.checked = true;
          });
        } else {
          field.value = saved[name];
        }
      }
    });
  };

  form.addEventListener("input", () => {
    const data = {};
    [...form.elements].forEach(field => {
      if (!field.name) return;
      if (field.type === "radio") {
        if (field.checked) data[field.name] = field.value;
      } else {
        data[field.name] = field.value;
      }
    });
    localStorage.setItem(formDataKey, JSON.stringify(data));
  });

  form.addEventListener("submit", () => {
    localStorage.removeItem(formDataKey);
  });
</script>
</body>
</html>
